package com.example.gestionstationskii.services.planning;

import com.example.gestionstationskii.dto.Requests;
import com.example.gestionstationskii.entities.*;
import com.example.gestionstationskii.repositories.*;
import com.example.gestionstationskii.services.IPlanningServices;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.transaction.annotation.Transactional;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
@Testcontainers(disabledWithoutDocker = true)
class PlanningServicesIntegrationTest {
    @Container
    private static final MySQLContainer<?> MYSQL = new MySQLContainer<>("mysql:8.0.33")
            .withDatabaseName("planning_test")
            .withUsername("planning_test")
            .withPassword("planning_test");

    @DynamicPropertySource
    static void databaseProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", MYSQL::getJdbcUrl);
        registry.add("spring.datasource.username", MYSQL::getUsername);
        registry.add("spring.datasource.password", MYSQL::getPassword);
    }

    @Autowired private IPlanningServices service;
    @Autowired private ICourseRepository courses;
    @Autowired private IInstructorRepository instructors;
    @Autowired private InstructorAvailabilityRepository availabilities;
    @Autowired private PlanningSlotRepository slots;
    @Autowired private IRegistrationRepository registrations;

    @BeforeEach
    void cleanPlanningData() {
        registrations.deleteAll();
        slots.deleteAll();
        availabilities.deleteAll();
        instructors.deleteAll();
        courses.deleteAll();
    }

    @Test
    void availabilityAndCreatedSlotArePersistedAndSearchable() {
        Fixture fixture = createFixture();
        Requests.Slot input = slotInput(fixture.course.getNumCourse(), fixture.instructor.getNumInstructor(), 6);

        PlanningSlot created = service.create(input);
        PlanningSlot loaded = service.get(created.getId());
        List<PlanningSlot> results = service.search(input.getStartTime().minusMinutes(30),
                input.getEndTime().plusMinutes(30), fixture.course.getNumCourse(),
                fixture.instructor.getNumInstructor(), true);

        assertNotNull(created.getId());
        assertEquals(SlotStatus.OPEN, loaded.getStatus());
        assertEquals(fixture.course.getNumCourse(), loaded.getCourse().getNumCourse());
        assertEquals(1, results.size());
        assertEquals(created.getId(), results.get(0).getId());
        assertEquals(1, service.availability(fixture.instructor.getNumInstructor()).size());
    }

    @Test
    void updatePersistsNewSlotTimeWhenThereIsNoRegistrationHistory() {
        Fixture fixture = createFixture();
        Requests.Slot initial = slotInput(fixture.course.getNumCourse(), fixture.instructor.getNumInstructor(), 6);
        PlanningSlot created = service.create(initial);
        Requests.Slot update = slotInput(fixture.course.getNumCourse(), fixture.instructor.getNumInstructor(), 5);
        update.setStartTime(initial.getStartTime().plusHours(1));
        update.setEndTime(initial.getEndTime().plusHours(1));

        PlanningSlot saved = service.update(created.getId(), update);

        assertEquals(update.getStartTime(), slots.findById(created.getId()).get().getStartTime());
        assertEquals(5, saved.getMaxCapacity());
    }

    @Test
    void cancellingSlotPersistsStatusAndCancelsItsRegistrations() {
        Fixture fixture = createFixture();
        PlanningSlot slot = service.create(slotInput(fixture.course.getNumCourse(), fixture.instructor.getNumInstructor(), 6));
        Registration registration = new Registration();
        registration.setCourse(fixture.course);
        registration.setPlanningSlot(slot);
        registration = registrations.saveAndFlush(registration);

        service.cancel(slot.getId());

        assertEquals(SlotStatus.CANCELLED, slots.findById(slot.getId()).get().getStatus());
        assertTrue(registrations.findById(registration.getNumRegistration()).get().isCancelled());
    }

    private Fixture createFixture() {
        Course course = new Course();
        course.setTypeCourse(TypeCourse.COLLECTIVE_ADULT);
        course.setSupport(Support.SKI);
        course.setLevel(1);
        course.setPrice(100F);
        course = courses.saveAndFlush(course);

        Instructor instructor = new Instructor();
        instructor.setFirstName("Planning");
        instructor.setLastName("Test");
        instructor.setCourses(Collections.singleton(course));
        instructor = instructors.saveAndFlush(instructor);

        LocalDate date = futureMonday();
        InstructorAvailability availability = new InstructorAvailability();
        availability.setInstructor(instructor);
        availability.setDayOfWeek(DayOfWeek.MONDAY);
        availability.setStartTime(LocalTime.of(9, 0));
        availability.setEndTime(LocalTime.of(13, 0));
        availability.setValidFrom(date.minusDays(7));
        availability.setValidUntil(date.plusDays(7));
        availabilities.saveAndFlush(availability);
        return new Fixture(course, instructor);
    }

    private static Requests.Slot slotInput(Long courseId, Long instructorId, int capacity) {
        Requests.Slot input = new Requests.Slot();
        input.setCourseId(courseId);
        input.setInstructorId(instructorId);
        LocalDate date = futureMonday();
        input.setStartTime(date.atTime(10, 0));
        input.setEndTime(date.atTime(11, 0));
        input.setMaxCapacity(capacity);
        return input;
    }

    private static LocalDate futureMonday() {
        return LocalDate.now().plusWeeks(2).with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY));
    }

    private static final class Fixture {
        private final Course course;
        private final Instructor instructor;

        private Fixture(Course course, Instructor instructor) {
            this.course = course;
            this.instructor = instructor;
        }
    }
}
