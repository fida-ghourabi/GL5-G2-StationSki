package com.example.gestionstationskii.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import com.example.gestionstationskii.dto.Requests;
import com.example.gestionstationskii.services.*;
import com.example.gestionstationskii.entities.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Tag(name = "\uD83D\uDC65 Subscription Management")
@RestController
@RequestMapping("/subscription")
@RequiredArgsConstructor
public class SubscriptionRestController {

    private final ISubscriptionServices subscriptionServices;

    @Operation(summary = "Supprimer un abonnement sans skieur ni paiement")
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id) { subscriptionServices.removeSubscription(id); }

    @Operation(summary = "Statut calculé de l'abonnement à une date donnée")
    @GetMapping("/{id}/status")
    public String status(@PathVariable Long id,
            @RequestParam @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE) LocalDate asOf) {
        return subscriptionServices.status(id, asOf);
    }

    @Operation(description = "Add Subscription ")
    @PostMapping("/add")
    public Subscription addSubscription(@RequestBody Requests.SubscriptionInput input){
        return subscriptionServices.addSubscription(toSubscription(input));
    }
    @Operation(description = "Retrieve Subscription by Id")
    @GetMapping("/get/{id-subscription}")
    public Subscription getById(@PathVariable("id-subscription") Long numSubscription){
        return subscriptionServices.retrieveSubscriptionById(numSubscription);
    }

    @Operation(description = "Retrieve Subscriptions by Type")
    @GetMapping("/all/{typeSub}")
    public Set<Subscription> getSubscriptionsByType(@PathVariable("typeSub")TypeSubscription typeSubscription){
        return subscriptionServices.getSubscriptionByType(typeSubscription);
    }
    @Operation(description = "Update Subscription ")
    @PutMapping("/update")
    public Subscription updateSubscription(@RequestBody Requests.SubscriptionInput input){
        return subscriptionServices.updateSubscription(toSubscription(input));
    }
    @Operation(description = "Retrieve Subscriptions created between two dates")
    @GetMapping("/all/{date1}/{date2}")
    public List<Subscription> getSubscriptionsByDates(@PathVariable("date1") @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE) LocalDate startDate,
                                                      @PathVariable("date2") @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE) LocalDate endDate){
        return subscriptionServices.retrieveSubscriptionsByDates(startDate, endDate);
    }

    private static Subscription toSubscription(Requests.SubscriptionInput input) {
        Subscription subscription = new Subscription();
        subscription.setNumSub(input.getNumSub());
        subscription.setStartDate(input.getStartDate());
        subscription.setPrice(input.getPrice());
        subscription.setTypeSub(input.getTypeSub());
        return subscription;
    }

}
